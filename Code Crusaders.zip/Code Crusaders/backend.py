from flask import Flask, redirect, url_for, request, render_template
app = Flask(__name__)

name = ""
q = 0
c = 0
p = [0, 0]
s = [0, 0]
messages = ["0/3 - Oops, keep practising!", "1/3 - You're getting better!", "2/3 - Nice! Almost there!", "3/3 - Conglatulations!"]
test = [["x multipled by 6 gives 66", "11", 0], ["Evaluate the following (x+28)/4=50", "172", 0], ["Find square root of 2704.", "52", 0], ["What are the openings in our noses?", "nostrils", 1], ["How many teeth do adults have?", "32", 1], ["If we were to fall and get cut what part of blood will help it get better?", "platelets", 1]]
assessmentquestions= [["35x=70", "2", 0, 0, 0], ["34x=102", "3", 0, 0, 0], ["107*7", "749", 0, 1, 0], ["142*9", "1728", 0, 1, 0], ["(x+4-18)/6 = 6", "50", 0, 2, 0], ["(x+9-24)/8 = 2", "31", 0, 2, 0], ["""Max works in the kitchen of a Chinese restaurant.
 On Sunday, he washed a total of 600 large and small plates.
 If Max washed 145 large plates, how many small dishes did he wash on Sunday?""", "455", 0, 3, 0], ["""A bakery currently mixes and bakes 354 cheesecakes.
  Another 780 cheesecakes are ready.
  How many cheesecakes are there?""", "1134", 0, 3, 0], ["""There were 700 bags of flour in the bakery.
  Then an employee made baguettes from 495 sacks of flour.
  How much flour is left?""", "205", 0, 4, 0], ["""After the vacation, the office manager has to read 890 emails.
    She has read 617 of them so far.
    How many emails are left for the office manager to read?""", "273", 0, 4, 0], ["How many chambers does the heart have?", "4", 1, 0, 0], ["Approximate size of the human heart? (relate it with your body)", "fist", 1, 1, 0], ["Can we see our internal organs if not what protects them? (name any 2)", "skin and bones", 1, 2, 0], ["What protects the lungs?", "ribcage", 1, 3, 0], ["What's the 10th element of the Periodic Table?", "neon", 1, 4, 0]]

@app.route('/')
def start():
    global name, q, c, p, s
    name = ""
    q = 0
    c = 0
    p = [0, 0]
    s = [0, 0]
    return render_template("login.html")

@app.route('/teststarts', methods=['POST', 'GET'])
def ts():
    global name
    name = request.form['name']
    return redirect(url_for('t'))
  
@app.route('/test')
def t():
    global q
    if q <= 5:
        q = q + 1
        return render_template("test.html", question=test[q-1][0])
    else:
        return redirect(url_for('success'))

@app.route('/check', methods=['POST', 'GET'])
def check():
    ans = request.form['ans']
    if ans.lower() == test[q-1][1]:
        s[test[q-1][2]] = s[test[q-1][2]] + 1
    return redirect(url_for('t'))

@app.route('/success')
def success():
    return render_template("success.html", s0=messages[s[0]], s1=messages[s[1]], name=name)

@app.route('/home')
def home():
    return render_template("home.html", s0=s[0], s1=s[1], name=name)

@app.route('/assessstarts')
def assessstarts():
    global q
    q = 0
    for i in range(15):
        assessmentquestions[i][4] = 0
    return redirect(url_for('assessment'))

@app.route('/assessment')
def assessment():
    global q, c
    if q == 0:
        for i in range(10):
            if assessmentquestions[i][3] == s[0] and assessmentquestions[i][4] == 0:
                assessmentquestions[i][4] = 1
                c = i
                return render_template("assessment.html", question=assessmentquestions[i][0], d=assessmentquestions[i][3] + 1)
        q = 1
    if q == 1:
        for i in range(10, 15):
            if assessmentquestions[i][3] == s[1] and assessmentquestions[i][4] == 0:
                assessmentquestions[i][4] = 1
                c = i
                return render_template("assessment.html", question=assessmentquestions[i][0], d=assessmentquestions[i][3] + 1)
    return render_template("home.html", s0=s[0], s1=s[1], name=name)

@app.route('/assesscheck', methods=['POST', 'GET'])
def assesscheck():
    global s
    ans = request.form['ans']
    if ans.lower() == assessmentquestions[c][1] and s[assessmentquestions[c][2]] <= 4:
        s[assessmentquestions[c][2]] = s[assessmentquestions[c][2]] + 1
    elif ans.lower() != assessmentquestions[c][1] and s[assessmentquestions[c][2]] >= 1:
        s[assessmentquestions[c][2]] = s[assessmentquestions[c][2]] - 1
    return redirect(url_for('assessment'))

if __name__ == '__main__':
    app.run(debug=True)
